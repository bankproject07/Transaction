package com.cg.obs.dao;

import java.util.List;

import com.cg.obs.bean.AccountMaster;
import com.cg.obs.bean.Customer;
import com.cg.obs.bean.RequestTable;
import com.cg.obs.bean.ServiceTracker;
import com.cg.obs.exception.UserException;

public interface IAdminDao 
{
	public Customer getCustomerbyId(int id) throws UserException;
	public List<RequestTable> getAllRequest() throws UserException;
	public RequestTable getAccountId(int custId) throws UserException;
	public void addUsers(AccountMaster accountMaster) throws UserException;
	public List<ServiceTracker> getAllService() throws UserException;
	
	public ServiceTracker getService(int serviceId) throws UserException;
	public void updateServiceStatus(ServiceTracker service) throws UserException;
	
	
	
}
